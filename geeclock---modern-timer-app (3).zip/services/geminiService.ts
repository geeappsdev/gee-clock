import { GoogleGenAI } from "@google/genai";

/**
 * Creates a new instance of the GoogleGenAI client.
 * This function is used to initialize the AI service with an API key provided by the user.
 * @param apiKey The user's Gemini API key.
 * @returns A new instance of GoogleGenAI.
 */
export const getGoogleGenAI = (apiKey: string) => {
  if (!apiKey) {
    throw new Error("API key is required to initialize GoogleGenAI.");
  }
  return new GoogleGenAI({ apiKey });
};
