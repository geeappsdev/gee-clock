import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MainContent } from './components/MainContent';
import { SettingsModal } from './components/SettingsModal';
import { ThemeName, AppSize, ColorMode } from './types';

const themes: Record<ThemeName, { light: Record<string, string>, dark: Record<string, string> }> = {
  default: {
    dark: {
      primary: '79 70 229', // indigo-600
      secondary: '16 185 129', // emerald-500
      background: '17 24 39', // gray-900
      surface: '31 41 55', // gray-800
      'text-primary': '249 250 251', // gray-50
      'text-secondary': '156 163 175', // gray-400
    },
    light: {
      primary: '79 70 229',
      secondary: '16 185 129',
      background: '243 244 246', // gray-100
      surface: '255 255 255', // white
      'text-primary': '17 24 39', // gray-900
      'text-secondary': '55 65 81', // gray-700
    }
  },
  ocean: {
    dark: {
      primary: '59 130 246', // blue-500
      secondary: '52 211 153', // emerald-400
      background: '15 23 42', // slate-900
      surface: '30 41 59', // slate-800
      'text-primary': '241 245 249', // slate-100
      'text-secondary': '148 163 184', // slate-400
    },
    light: {
      primary: '59 130 246',
      secondary: '22 163 74', // green-600
      background: '240 249 255', // light blue-50
      surface: '255 255 255', // white
      'text-primary': '30 41 59', // slate-800
      'text-secondary': '71 85 105', // slate-600
    }
  },
  sunset: {
    dark: {
      primary: '249 115 22', // orange-500
      secondary: '239 68 68', // red-500
      background: '28 25 23', // stone-900
      surface: '41 37 36', // stone-800
      'text-primary': '250 250 249', // stone-50
      'text-secondary': '168 162 158', // stone-400
    },
    light: {
      primary: '234 88 12', // orange-600
      secondary: '220 38 38', // red-600
      background: '254 252 251', // stone-50
      surface: '255 255 255', // white
      'text-primary': '28 25 23', // stone-900
      'text-secondary': '68 64 60', // stone-700
    }
  },
  forest: {
    dark: {
      primary: '34 197 94', // green-500
      secondary: '202 138 4', // yellow-500
      background: '20 30 20', // dark green
      surface: '30 46 30', // darker green
      'text-primary': '220 252 231', // green-50
      'text-secondary': '163 230 170', // green-200
    },
    light: {
      primary: '22 163 74', // green-600
      secondary: '202 138 4', // yellow-500
      background: '240 253 244', // green-50
      surface: '255 255 255', // white
      'text-primary': '21 21 21',
      'text-secondary': '63 63 63',
    }
  },
  graphite: {
    dark: {
      primary: '148 163 184', // slate-400
      secondary: '100 116 139', // slate-500
      background: '15 23 42', // slate-900
      surface: '30 41 59', // slate-800
      'text-primary': '241 245 249', // slate-100
      'text-secondary': '148 163 184', // slate-400
    },
    light: {
      primary: '71 85 105', // slate-600
      secondary: '100 116 139', // slate-500
      background: '241 245 249', // slate-100
      surface: '255 255 255', // white
      'text-primary': '15 23 42', // slate-900
      'text-secondary': '51 65 85', // slate-700
    }
  },
  rose: {
    dark: {
      primary: '251 113 133', // rose-400
      secondary: '251 146 60', // amber-400
      background: '53 23 29',
      surface: '79 32 43',
      'text-primary': '255 241 242', // rose-50
      'text-secondary': '253 164 175', // rose-300
    },
    light: {
      primary: '244 63 94', // rose-500
      secondary: '217 119 6', // amber-500
      background: '255 241 242', // rose-50
      surface: '255 255 255', // white
      'text-primary': '131 24 67', // rose-900
      'text-secondary': '190 24 93', // rose-700
    }
  }
};


const App: React.FC = () => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [theme, setTheme] = useState<ThemeName>('default');
  const [size, setSize] = useState<AppSize>('md');
  const [colorMode, setColorMode] = useState<ColorMode>('dark');

  useEffect(() => {
    // FIX: Safely retrieve and validate theme from localStorage before setting state.
    const savedTheme = localStorage.getItem('gee-theme');
    if (savedTheme && savedTheme in themes) {
      setTheme(savedTheme as ThemeName);
    }
    // FIX: Safely retrieve and validate size from localStorage before setting state.
    const savedSize = localStorage.getItem('gee-size');
    if (savedSize && ['sm', 'md', 'lg'].includes(savedSize)) {
      setSize(savedSize as AppSize);
    }
    const savedColorMode = localStorage.getItem('gee-color-mode');
    if (savedColorMode && (savedColorMode === 'light' || savedColorMode === 'dark')) {
      setColorMode(savedColorMode as ColorMode);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const themeColors = themes[theme][colorMode];
    Object.entries(themeColors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value);
    });

    if (colorMode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    localStorage.setItem('gee-theme', theme);
    localStorage.setItem('gee-size', size);
    localStorage.setItem('gee-color-mode', colorMode);

  }, [theme, size, colorMode]);


  const handleOpenSettings = () => setIsSettingsOpen(true);
  const handleCloseSettings = () => setIsSettingsOpen(false);

  return (
    <div className="min-h-screen transition-colors duration-300">
      <Header onOpenSettings={handleOpenSettings} />
      <MainContent size={size} />
      {/* Fix: Wrapped state setters in lambdas to prevent potential type inference issues. */}
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={handleCloseSettings}
        currentTheme={theme}
        // FIX: Explicitly typed the `newTheme` parameter to resolve a type inference error where it was being inferred as `unknown`.
        onThemeChange={(newTheme: ThemeName) => setTheme(newTheme)}
        currentSize={size}
        // FIX: Explicitly typed the `newSize` parameter to resolve a type inference error where it was being inferred as `unknown`.
        onSizeChange={(newSize: AppSize) => setSize(newSize)}
        currentColorMode={colorMode}
        onColorModeChange={(newMode: ColorMode) => setColorMode(newMode)}
      />
    </div>
  );
};

export default App;