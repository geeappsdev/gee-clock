export interface Message {
  sender: 'user' | 'ai';
  text: string;
}

export interface TimerInfo {
  id: number;
  initialDuration: number; // in seconds
}

export type ThemeName = 'default' | 'ocean' | 'sunset' | 'forest' | 'graphite' | 'rose';
export type AppSize = 'sm' | 'md' | 'lg';
export type ColorMode = 'light' | 'dark';
