import React, { useState, useEffect, useRef } from 'react';
import { TimerInfo, AppSize } from '../types';
import { AddTimerModal } from './AddTimerModal';
import { Icon } from './Icon';

const formatTime = (totalSeconds: number) => {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds]
    .map(v => v.toString().padStart(2, '0'))
    .join(':');
};

interface TimerProps {
  timerInfo: TimerInfo;
  onDelete: (id: number) => void;
  size: AppSize;
  alarmAudioRef: React.RefObject<HTMLAudioElement>;
}

const Timer: React.FC<TimerProps> = ({ timerInfo, onDelete, size, alarmAudioRef }) => {
  const [remainingTime, setRemainingTime] = useState(timerInfo.initialDuration);
  const [isRunning, setIsRunning] = useState(true);
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    let interval: number | null = null;
    if (isRunning && remainingTime > 0) {
      interval = window.setInterval(() => {
        setRemainingTime(prev => prev - 1);
      }, 1000);
    } else if (remainingTime === 0 && isRunning) {
      setIsRunning(false);
      setIsExpired(true);
      alarmAudioRef.current?.play().catch(e => console.error("Alarm playback failed. The browser may have blocked it without user interaction.", e));
      document.title = "Time's up!";
      setTimeout(() => {
        document.title = "GeeClock";
      }, 5000)
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, remainingTime, alarmAudioRef]);

  const handleTogglePlay = () => {
    if (remainingTime > 0) {
        setIsRunning(!isRunning);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsExpired(false);
    setRemainingTime(timerInfo.initialDuration);
  };
  
  const progress = (timerInfo.initialDuration - remainingTime) / timerInfo.initialDuration * 100;

  const sizeClasses = {
    sm: { container: "p-4", time: "text-4xl", total: "text-xs", buttons: "gap-2", resetBtn: "p-2", playBtn: "p-3", playIcon: "w-6 h-6", },
    md: { container: "p-6", time: "text-5xl", total: "text-sm", buttons: "gap-4", resetBtn: "p-3", playBtn: "p-4", playIcon: "w-8 h-8", },
    lg: { container: "p-8", time: "text-6xl", total: "text-base", buttons: "gap-5", resetBtn: "p-4", playBtn: "p-5", playIcon: "w-10 h-10", }
  };
  const styles = sizeClasses[size];

  return (
    <div className={`bg-surface rounded-lg p-6 shadow-lg border border-primary/20 relative overflow-hidden ${styles.container}`}>
        <div 
            className="absolute top-0 left-0 h-full bg-primary/20 transition-all duration-500 ease-linear"
            style={{ width: `${progress}%`}}
        ></div>
        <div className="relative z-10">
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                    <Icon name="clock" className="w-5 h-5 text-secondary" />
                    <span className="font-semibold text-text-primary">Timer</span>
                </div>
                <button 
                    onClick={() => onDelete(timerInfo.id)}
                    className="p-1 rounded-full text-text-secondary hover:bg-surface transition-colors"
                    aria-label="Delete timer"
                >
                    <Icon name="trash" className="w-5 h-5" />
                </button>
            </div>
            <div className="text-center my-4">
                <p className={`font-mono font-bold tracking-wider ${styles.time} ${isExpired ? 'text-red-500 animate-pulse' : 'text-text-primary'}`}>
                    {formatTime(remainingTime)}
                </p>
                <p className={`text-text-secondary ${styles.total}`}>
                    Total: {formatTime(timerInfo.initialDuration)}
                </p>
            </div>
            <div className={`flex justify-center ${styles.buttons}`}>
                <button onClick={handleReset} className={`rounded-full bg-surface/50 hover:bg-surface transition-colors text-text-secondary ${styles.resetBtn}`} aria-label="Reset timer">
                    <Icon name="reset" className="w-6 h-6" />
                </button>
                <button onClick={handleTogglePlay} className={`rounded-full bg-secondary text-background hover:bg-secondary/80 transition-colors ${styles.playBtn}`} aria-label={isRunning ? "Pause timer" : "Play timer"}>
                    <Icon name={isRunning ? 'pause' : 'play'} className={styles.playIcon} />
                </button>
            </div>
        </div>
    </div>
  );
};


export const MainContent: React.FC<{size: AppSize}> = ({ size }) => {
    const [timers, setTimers] = useState<TimerInfo[]>([]);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const alarmAudioRef = useRef<HTMLAudioElement>(null);
    const [isAudioUnlocked, setIsAudioUnlocked] = useState(false);

    useEffect(() => {
        try {
            const savedTimers = localStorage.getItem('gee-timers');
            if (savedTimers) {
                setTimers(JSON.parse(savedTimers));
            }
        } catch (error) {
            console.error("Failed to load timers from localStorage", error);
        }
    }, []);

    useEffect(() => {
        try {
            localStorage.setItem('gee-timers', JSON.stringify(timers));
        } catch (error) {
            console.error("Failed to save timers to localStorage", error);
        }
    }, [timers]);
    
    const handleAddTimer = (durationInSeconds: number) => {
        if (!isAudioUnlocked && alarmAudioRef.current) {
            const promise = alarmAudioRef.current.play();
            if (promise !== undefined) {
                promise.then(() => {
                    // Autoplay started, so we can pause it and know that future plays will be allowed.
                    alarmAudioRef.current?.pause();
                    if(alarmAudioRef.current) {
                        alarmAudioRef.current.currentTime = 0;
                    }
                    setIsAudioUnlocked(true);
                }).catch(error => {
                    // Autoplay was prevented.
                    console.error("Audio could not be unlocked automatically:", error);
                });
            }
        }

        const newTimer: TimerInfo = {
            id: Date.now(),
            initialDuration: durationInSeconds
        };
        setTimers(prev => [...prev, newTimer]);
    };
    
    const handleDeleteTimer = (id: number) => {
        setTimers(prev => prev.filter(timer => timer.id !== id));
    };
    
    const sizeClasses = {
        sm: { minHeight: "min-h-[220px]" },
        md: { minHeight: "min-h-[250px]" },
        lg: { minHeight: "min-h-[280px]" }
    };
    const styles = sizeClasses[size];

    return (
        <main className="container mx-auto px-4 py-24">
            <audio ref={alarmAudioRef} src="data:audio/mpeg;base64,SUQzAwAAAAABOlRTU0UAAAASAAAATEFNRTMuOTkuNVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/x/EQA8AAAACAAADSAAAAICgAAPAAAAAwCAAAAAUAAA4iIHgAAB1f+x5+JyJc7gEzL6wZb+S17QYfAUAAAAAAD/+x5+JyJc7gEzL6wZb+S17QYfAUAAAAAAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/6H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7Hn4nIlzuATMvrBlv5LXtBh8BQAAAAAAA//seficmXO4BMy+sGW/kte0GHwFAAAAAAAD/+//5g8j2543gmw7jW3p/pD//7/l83x3d/+3+35//f9/f3p7f/P35/f/f3/7//6/rf//+d/2///v9/8M/9g/79/+5/f3/7v+3//2f////+qX/H///+n//5f/zP/+///0//v/+v/+//9//8AAAP/7AH//+n//5f/zP/+///0//v/+v/+//9//8AAAP/"></audio>
            {timers.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {timers.map(timer => (
                        <Timer key={timer.id} timerInfo={timer} onDelete={handleDeleteTimer} size={size} alarmAudioRef={alarmAudioRef} />
                    ))}
                    <div className={`flex items-center justify-center rounded-lg border-2 border-dashed border-surface ${styles.minHeight}`}>
                        <button onClick={() => setIsAddModalOpen(true)} className="flex flex-col items-center justify-center w-full h-full text-text-secondary hover:bg-surface/50 transition-colors rounded-lg">
                            <Icon name="plus" className="w-12 h-12" />
                            <span className="mt-2 font-semibold">Add New Timer</span>
                        </button>
                    </div>
                </div>
            ) : (
                <div className="text-center py-20">
                    <div className="inline-block p-6 bg-surface rounded-full">
                         <Icon name="clock" className="w-16 h-16 text-secondary" />
                    </div>
                    <h2 className="mt-6 text-2xl font-semibold text-text-primary">No timers running</h2>
                    <p className="mt-2 text-text-secondary">Click the button below to add your first timer.</p>
                    <button onClick={() => setIsAddModalOpen(true)} className="mt-6 inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary/80 transition-transform transform hover:scale-105">
                         <Icon name="plus" className="w-5 h-5"/>
                        Add a Timer
                    </button>
                </div>
            )}
            <AddTimerModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onAddTimer={handleAddTimer} />
        </main>
    );
};