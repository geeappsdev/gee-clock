import React, { useState, useEffect, useRef } from 'react';
import { Icon } from './Icon';

interface AddTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTimer: (durationInSeconds: number) => void;
}

export const AddTimerModal: React.FC<AddTimerModalProps> = ({ isOpen, onClose, onAddTimer }) => {
  const [hours, setHours] = useState('');
  const [minutes, setMinutes] = useState('');
  const [seconds, setSeconds] = useState('');
  const firstInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      // Reset fields when opening
      setHours('');
      setMinutes('');
      setSeconds('');
      // Focus on the first input
      setTimeout(() => firstInputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const h = parseInt(hours) || 0;
    const m = parseInt(minutes) || 0;
    const s = parseInt(seconds) || 0;
    const totalSeconds = h * 3600 + m * 60 + s;

    if (totalSeconds > 0) {
      onAddTimer(totalSeconds);
      onClose();
    } else {
        alert("Please enter a valid duration.");
    }
  };

  const handleInputChange = (
    value: string, 
    setter: React.Dispatch<React.SetStateAction<string>>,
    max: number
  ) => {
    const num = parseInt(value);
    if (value === '' || (!isNaN(num) && num >= 0 && num <= max)) {
        setter(value);
    }
  }

  return (
    <div 
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in" 
      onClick={onClose}
    >
      <div 
        className="bg-surface rounded-lg shadow-2xl w-full max-w-sm border border-surface"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-surface flex justify-between items-center">
          <h2 className="text-xl font-bold text-text-primary">Add New Timer</h2>
          <button onClick={onClose} className="p-1 rounded-full text-text-secondary hover:bg-surface">
            <Icon name="close" className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="flex justify-center items-center gap-2 font-mono text-4xl">
                <input 
                    ref={firstInputRef}
                    type="number" 
                    value={hours}
                    onChange={(e) => handleInputChange(e.target.value, setHours, 99)}
                    placeholder="00"
                    className="w-24 bg-background text-text-primary text-center rounded-md p-2 focus:ring-2 focus:ring-primary outline-none border border-surface"
                    aria-label="Hours"
                />
                <span className="text-text-secondary">:</span>
                <input 
                    type="number" 
                    value={minutes}
                    onChange={(e) => handleInputChange(e.target.value, setMinutes, 59)}
                    placeholder="00"
                    className="w-24 bg-background text-text-primary text-center rounded-md p-2 focus:ring-2 focus:ring-primary outline-none border border-surface"
                    aria-label="Minutes"
                />
                <span className="text-text-secondary">:</span>
                <input 
                    type="number" 
                    value={seconds}
                    onChange={(e) => handleInputChange(e.target.value, setSeconds, 59)}
                    placeholder="00"
                    className="w-24 bg-background text-text-primary text-center rounded-md p-2 focus:ring-2 focus:ring-primary outline-none border border-surface"
                    aria-label="Seconds"
                />
            </div>
            <button 
                type="submit" 
                className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white font-semibold rounded-md hover:bg-primary/80 transition-colors disabled:bg-gray-600"
            >
                <Icon name="plus" className="w-5 h-5"/>
                Start Timer
            </button>
        </form>
      </div>
    </div>
  );
};