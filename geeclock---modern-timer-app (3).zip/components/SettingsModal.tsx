import React, { useState } from 'react';
import { Icon } from './Icon';
import { GeeApps } from './GeeApps';
import { ThemeName, AppSize, ColorMode } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: ThemeName;
  onThemeChange: (theme: ThemeName) => void;
  currentSize: AppSize;
  onSizeChange: (size: AppSize) => void;
  currentColorMode: ColorMode;
  onColorModeChange: (mode: ColorMode) => void;
}

const SECRET_CLICK_COUNT = 5;

const themeOptions: {name: ThemeName, bg: string, label: string}[] = [
    { name: 'default', bg: 'bg-indigo-500', label: 'Default' },
    { name: 'ocean', bg: 'bg-blue-500', label: 'Ocean' },
    { name: 'sunset', bg: 'bg-orange-500', label: 'Sunset' },
    { name: 'forest', bg: 'bg-green-500', label: 'Forest' },
    { name: 'graphite', bg: 'bg-slate-500', label: 'Graphite' },
    { name: 'rose', bg: 'bg-rose-500', label: 'Rose Gold' },
];

const sizeOptions: {name: AppSize, label: string}[] = [
    { name: 'sm', label: 'S' },
    { name: 'md', label: 'M' },
    { name: 'lg', label: 'L' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({ 
    isOpen, 
    onClose,
    currentTheme,
    onThemeChange,
    currentSize,
    onSizeChange,
    currentColorMode,
    onColorModeChange
 }) => {
  const [titleClickCount, setTitleClickCount] = useState(0);
  const [showSecretFeature, setShowSecretFeature] = useState(false);

  if (!isOpen) return null;

  const handleTitleClick = () => {
    if (showSecretFeature) return;
    const newCount = titleClickCount + 1;
    setTitleClickCount(newCount);
    if (newCount >= SECRET_CLICK_COUNT) {
      setShowSecretFeature(true);
    }
  };

  const handleClose = () => {
    setTitleClickCount(0);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={handleClose}>
      <div 
        className="bg-surface rounded-lg shadow-2xl w-full max-w-2xl border border-gray-700 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-700 flex justify-between items-center sticky top-0 bg-surface/80">
          <h2 
            className="text-2xl font-bold text-text-primary select-none"
            onClick={handleTitleClick}
          >
            Settings
          </h2>
          <button onClick={handleClose} className="p-1 rounded-full text-text-secondary hover:bg-gray-600">
            <Icon name="close" className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 space-y-8">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-text-primary">Appearance</h3>
            
            <div className="">
                <label className="block text-text-secondary mb-2">Mode</label>
                <div className="flex gap-2 bg-background p-1 rounded-lg">
                    <button
                        onClick={() => onColorModeChange('light')}
                        className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-md transition-colors ${currentColorMode === 'light' ? 'bg-primary text-white' : 'hover:bg-surface'}`}
                    >
                        <Icon name="sun" className="w-5 h-5"/>
                        <span>Light</span>
                    </button>
                    <button
                        onClick={() => onColorModeChange('dark')}
                        className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-md transition-colors ${currentColorMode === 'dark' ? 'bg-primary text-white' : 'hover:bg-surface'}`}
                    >
                        <Icon name="moon" className="w-5 h-5"/>
                        <span>Dark</span>
                    </button>
                </div>
            </div>

            <div className="">
              <label className="block text-text-secondary mb-2">Theme</label>
              <div className="flex flex-wrap gap-4">
                {themeOptions.map(theme => (
                    <button key={theme.name} onClick={() => onThemeChange(theme.name)} className="flex items-center gap-2 text-left">
                        <div className={`w-6 h-6 rounded-full ${theme.bg} border-2 ${currentTheme === theme.name ? 'border-primary' : 'border-transparent'}`}></div>
                        <span className={currentTheme === theme.name ? 'text-text-primary font-semibold' : 'text-text-secondary'}>{theme.label}</span>
                    </button>
                ))}
              </div>
            </div>

             <div className="">
              <label className="block text-text-secondary mb-2">Size</label>
              <div className="flex gap-2 bg-background p-1 rounded-lg">
                {sizeOptions.map(size => (
                    <button 
                        key={size.name}
                        onClick={() => onSizeChange(size.name)}
                        className={`w-12 h-10 rounded ${currentSize === size.name ? 'bg-primary text-white font-bold' : 'hover:bg-surface'}`}
                    >
                       {size.label}
                    </button>
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-4 border-t border-gray-700 pt-8">
            <h3 className="text-lg font-semibold text-text-primary">About</h3>
            <div className="flex justify-between items-center">
              <span className="text-text-secondary">App Version</span>
              <span className="text-text-primary font-mono">1.1.0-beta</span>
            </div>
          </div>
          
          {showSecretFeature && <GeeApps />}
        </div>
      </div>
    </div>
  );
};