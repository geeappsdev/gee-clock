import React, { useState, useEffect } from 'react';

export const Clock: React.FC = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timerId = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timerId);
    };
  }, []);

  const formattedTime = time.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const formattedDate = time.toLocaleDateString([], {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
  
  const timeZone = time.toLocaleTimeString('en-us',{timeZoneName:'short'}).split(' ')[2];

  return (
    <div 
      className="text-right hidden sm:block font-mono"
      aria-live="polite"
      aria-atomic="true"
      aria-label={`The current time is ${formattedTime}`}
    >
      <div className="text-lg text-text-primary">{formattedTime}</div>
      <div className="text-xs text-text-secondary">{`${formattedDate} | ${timeZone}`}</div>
    </div>
  );
};