import React from 'react';
import { Icon } from './Icon';
import { Clock } from './Clock';

interface HeaderProps {
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  return (
    <header className="bg-surface/50 backdrop-blur-sm p-4 border-b border-surface fixed top-0 left-0 right-0 z-10">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
            <Icon name="clock" className="w-6 h-6 text-secondary"/>
            <h1 className="text-xl font-bold text-text-primary">GeeClock</h1>
        </div>
        
        <Clock />

        <button
          onClick={onOpenSettings}
          className="p-2 rounded-full hover:bg-surface transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
          aria-label="Open settings"
        >
          <Icon name="settings" className="w-6 h-6 text-text-secondary" />
        </button>
      </div>
    </header>
  );
};